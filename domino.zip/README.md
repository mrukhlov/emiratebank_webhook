#How to change context replies on user choice via Api.ai Webhook

This example shows how you can use Api.ai webhook to provide different parameters depending on user reply.

<a href="https://heroku.com/deploy" target="_blank"><img src="https://www.herokucdn.com/deploy/button.svg"></a>